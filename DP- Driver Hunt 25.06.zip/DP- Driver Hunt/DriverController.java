package com.driverhunt.controller;

import com.driverhunt.models.Driver;
import com.driverhunt.services.DriverService;
import io.javalin.http.Context;
import io.javalin.http.UploadedFile;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DriverController {
    private DriverService driverService = new DriverService();
    private Gson gson = new Gson();

    public void registerDriver(Context ctx) {
        // Using formParam for regular fields and uploadedFile for files
        String name = ctx.formParam("driverName");
        int age = Integer.parseInt(ctx.formParam("driverAge"));
        String gender = ctx.formParam("driverGender");
        String dlNumber = ctx.formParam("driverDL");
        // Get multiple values for 'vehicles'
        List<String> vehicles = Arrays.asList(ctx.formParams("vehicles").toArray(new String[0]));
        int experience = Integer.parseInt(ctx.formParam("driverExperience"));
        String phoneNumber = ctx.formParam("driverPhone");
        String address = ctx.formParam("driverAddress");
        String workingTimings = ctx.formParam("driverTimings");

        // Handle file uploads
        UploadedFile profilePicFile = ctx.uploadedFile("profilePicture");
        UploadedFile idProofFile = ctx.uploadedFile("idProof");
        UploadedFile drivingLicenseFile = ctx.uploadedFile("drivingLicense");

        if (name == null || name.isEmpty() || !name.matches("[A-Za-z\\s]+") ||
            String.valueOf(age).length() != 2 || age < 1 || age > 99 ||
            gender == null || gender.isEmpty() ||
            dlNumber == null || !dlNumber.matches("DL[0-9]{4}") ||
            vehicles.isEmpty() || vehicles.size() > 7 ||
            experience < 1 || experience > 30 ||
            phoneNumber == null || !phoneNumber.matches("0000000[0-9]{3}") ||
            address == null || address.isEmpty() ||
            workingTimings == null || workingTimings.isEmpty() ||
            profilePicFile == null || idProofFile == null || drivingLicenseFile == null) {
            ctx.status(400).json(createResponse("Invalid driver data or missing uploads.", false));
            return;
        }

        String profilePictureUrl = saveUploadedFile(profilePicFile);
        String idProofUrl = saveUploadedFile(idProofFile);
        String drivingLicenseUrl = saveUploadedFile(drivingLicenseFile);

        if (profilePictureUrl == null || idProofUrl == null || drivingLicenseUrl == null) {
            ctx.status(500).json(createResponse("Failed to save uploaded files.", false));
            return;
        }

        Driver driver = new Driver();
        driver.setName(name);
        driver.setAge(age);
        driver.setGender(gender);
        driver.setDlNumber(dlNumber);
        driver.setVehiclesCanDrive(vehicles);
        driver.setExperience(experience);
        driver.setPhoneNumber(phoneNumber);
        driver.setAddress(address);
        driver.setWorkingTimings(workingTimings);
        driver.setProfilePictureUrl(profilePictureUrl);
        driver.setIdProofUrl(idProofUrl);
        driver.setDrivingLicenseUrl(drivingLicenseUrl);

        if (driverService.registerDriver(driver)) {
            ctx.status(201).json(createResponse("Driver registered successfully! Awaiting verification.", true));
        } else {
            ctx.status(500).json(createResponse("Driver registration failed.", false));
        }
    }

    public void getVerifiedDrivers(Context ctx) {
        List<Driver> drivers = driverService.getAvailableDrivers();
        if (drivers.isEmpty()) {
            ctx.status(200).json(createResponse("No drivers available at the moment.", true, drivers));
        } else {
            ctx.json(createResponse("Drivers retrieved successfully.", true, drivers));
        }
    }

    public void getDriverDetails(Context ctx) {
        int driverId = ctx.pathParam("id", Integer.class).get();
        Driver driver = driverService.getDriverDetails(driverId);
        if (driver != null) {
            ctx.json(createResponse("Driver details retrieved.", true, driver));
        } else {
            ctx.status(404).json(createResponse("Driver not found.", false));
        }
    }

    private String saveUploadedFile(UploadedFile file) {
        String uploadDir = "uploads"; // Directory to save uploaded files
        try {
            Files.createDirectories(Paths.get(uploadDir));
            String fileName = UUID.randomUUID().toString() + "_" + file.getFilename();
            Path filePath = Paths.get(uploadDir, fileName);
            Files.copy(file.getContent(), filePath, StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/" + fileName; // Return a URL path
        } catch (Exception e) {
            System.err.println("Error saving uploaded file: " + e.getMessage());
            return null;
        }
    }

    private Map<String, Object> createResponse(String message, boolean success) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("success", success);
        return response;
    }

    private Map<String, Object> createResponse(String message, boolean success, Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("success", success);
        response.put("data", data);
        return response;
    }
}