document.addEventListener('DOMContentLoaded', () => {
    // --- Index Page Logic ---
    const primaryButton = document.querySelector('.primary-button');
    const secondaryButton = document.querySelector('.secondary-button');

    if (primaryButton) {
        primaryButton.addEventListener('click', (e) => {
            // e.preventDefault(); // Uncomment if you want to handle navigation via JS
            console.log('Book a Driver clicked');
            // window.location.href = 'book_driver.html'; // Example navigation
        });
    }

    if (secondaryButton) {
        secondaryButton.addEventListener('click', (e) => {
            // e.preventDefault(); // Uncomment if you want to handle navigation via JS
            console.log('Register as Driver clicked');
            // window.location.href = 'register_driver.html'; // Example navigation
        });
    }

    // --- Sign Up Form (signup.html) ---
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const fullName = document.getElementById('fullName').value;
            const phone = document.getElementById('phone').value;
            const email = document.getElementById('email').value;
            const address = document.getElementById('address').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const signupMessage = document.getElementById('signupMessage');

            // Basic client-side validation
            if (password.length < 6) {
                signupMessage.textContent = 'Password must be at least 6 characters long.';
                signupMessage.className = 'message error';
                return;
            }
            if (password !== confirmPassword) {
                signupMessage.textContent = 'Passwords do not match.';
                signupMessage.className = 'message error';
                return;
            }
            if (!/\S+@\S+\.\S+/.test(email)) {
                signupMessage.textContent = 'Please enter a valid email address.';
                signupMessage.className = 'message error';
                return;
            }
            if (!/^[0-9]{10}$/.test(phone)) {
                signupMessage.textContent = 'Phone number must be 10 digits.';
                signupMessage.className = 'message error';
                return;
            }

            // Simulate API call to backend for user registration
            // In a real application, you'd send this data via fetch/XMLHttpRequest
            // to your Java backend (e.g., /api/signup)
            console.log('Attempting to register user:', { fullName, phone, email, address, password });

            // Simulate successful registration
            setTimeout(() => {
                signupMessage.textContent = 'Account created successfully! Redirecting to login...';
                signupMessage.className = 'message success';
                setTimeout(() => {
                    window.location.href = 'login.html'; // Redirect to login page
                }, 2000);
            }, 1000);

            // In a real app, it would be something like:
            /*
            fetch('/api/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fullName, phone, email, address, password })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    signupMessage.textContent = 'Account created successfully! Redirecting to login...';
                    signupMessage.className = 'message success';
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 2000);
                } else {
                    signupMessage.textContent = data.message || 'Registration failed.';
                    signupMessage.className = 'message error';
                }
            })
            .catch(error => {
                console.error('Error during signup:', error);
                signupMessage.textContent = 'An error occurred during registration. Please try again.';
                signupMessage.className = 'message error';
            });
            */
        });
    }

    // --- Login Form (login.html) ---
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const loginIdentifier = document.getElementById('loginIdentifier').value;
            const loginPassword = document.getElementById('loginPassword').value;
            const loginMessage = document.getElementById('loginMessage');

            // Simulate API call to backend for login
            // In a real application, you'd send this data via fetch/XMLHttpRequest
            console.log('Attempting to log in:', { loginIdentifier, loginPassword });

            // Simulate successful login
            setTimeout(() => {
                loginMessage.textContent = 'Login successful! Redirecting...';
                loginMessage.className = 'message success';
                // In a real app, redirect to employer dashboard
                window.location.href = 'employer_dashboard.html'; // Placeholder for employer dashboard
            }, 1000);

            // In a real app, it would be something like:
            /*
            fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ identifier: loginIdentifier, password: loginPassword })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loginMessage.textContent = 'Login successful! Redirecting...';
                    loginMessage.className = 'message success';
                    window.location.href = 'employer_dashboard.html'; // Redirect to user dashboard
                } else {
                    loginMessage.textContent = data.message || 'Invalid credentials.';
                    loginMessage.className = 'message error';
                }
            })
            .catch(error => {
                console.error('Error during login:', error);
                loginMessage.textContent = 'An error occurred during login. Please try again.';
                loginMessage.className = 'message error';
            });
            */
        });
    }

    // --- Driver Registration Form (register_driver.html) ---
    const driverRegistrationForm = document.getElementById('driverRegistrationForm');
    if (driverRegistrationForm) {
        const vehicleCheckboxes = driverRegistrationForm.querySelectorAll('input[name="vehicles"]');
        const vehicleSelectionHelp = document.getElementById('vehicleSelectionHelp');

        driverRegistrationForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const registrationMessage = document.getElementById('registrationMessage');
            registrationMessage.textContent = '';
            registrationMessage.className = 'message'; // Reset message style

            // Client-side validation for mandatory fields and specific formats
            const name = document.getElementById('driverName').value;
            const age = document.getElementById('driverAge').value;
            const gender = document.getElementById('driverGender').value;
            const dlNumber = document.getElementById('driverDL').value;
            const experience = document.getElementById('driverExperience').value;
            const phoneNumber = document.getElementById('driverPhone').value;
            const address = document.getElementById('driverAddress').value;
            const workingTimings = document.getElementById('driverTimings').value;

            // Name validation
            if (!/^[A-Za-z\s]+$/.test(name)) {
                registrationMessage.textContent = 'Name must only contain letters.';
                registrationMessage.className = 'message error';
                return;
            }

            // Age validation
            if (!/^[0-9]{2}$/.test(age) || parseInt(age) < 1 || parseInt(age) > 99) { // Added 1-99 range for realism
                registrationMessage.textContent = 'Age must be exactly 2 digits (e.g., 25).';
                registrationMessage.className = 'message error';
                return;
            }

            // DL number validation
            if (!/^DL[0-9]{4}$/.test(dlNumber)) {
                registrationMessage.textContent = 'DL number must start with "DL" followed by exactly four numbers (e.g., DL1234).';
                registrationMessage.className = 'message error';
                return;
            }

            // Vehicles can drive validation (max 7)
            const selectedVehicles = Array.from(vehicleCheckboxes).filter(cb => cb.checked);
            if (selectedVehicles.length > 7) {
                registrationMessage.textContent = 'You can select a maximum of 7 vehicles.';
                registrationMessage.className = 'message error';
                return;
            }
            if (selectedVehicles.length === 0) {
                 registrationMessage.textContent = 'Please select at least one vehicle you can drive.';
                 registrationMessage.className = 'message error';
                 return;
            }


            // Experience validation
            if (parseInt(experience) < 1 || parseInt(experience) > 30) {
                registrationMessage.textContent = 'Experience must be between 1 and 30 years.';
                registrationMessage.className = 'message error';
                return;
            }

            // Phone Number validation
            if (!/^0000000[0-9]{3}$/.test(phoneNumber)) {
                registrationMessage.textContent = 'Phone number must be a 10-digit number and start with "0000000" (e.g., 0000000123).';
                registrationMessage.className = 'message error';
                return;
            }

            // File uploads validation (check if files are selected)
            const profilePicture = document.getElementById('profilePicture').files.length;
            const idProof = document.getElementById('idProof').files.length;
            const drivingLicense = document.getElementById('drivingLicense').files.length;

            if (!profilePicture || !idProof || !drivingLicense) {
                registrationMessage.textContent = 'All mandatory documents (Profile Picture, ID Proof, Driving License) must be uploaded.';
                registrationMessage.className = 'message error';
                return;
            }

            // Prepare form data for submission (including files)
            const formData = new FormData(driverRegistrationForm);

            // Append selected vehicles as an array (if backend expects it this way)
            formData.delete('vehicles'); // Remove original, potentially comma-separated string
            selectedVehicles.forEach(cb => formData.append('vehicles', cb.value));


            console.log('Attempting to register driver:', Object.fromEntries(formData.entries()));

            // Simulate successful driver registration
            setTimeout(() => {
                registrationMessage.textContent = 'Driver profile created successfully!';
                registrationMessage.className = 'message success';
                // In a real app, you might redirect to a "thank you" page or driver dashboard login
                // For now, clear form after success
                driverRegistrationForm.reset();
            }, 1500);

            // In a real app, use fetch with FormData for file uploads:
            /*
            fetch('/api/registerDriver', {
                method: 'POST',
                body: formData // No Content-Type header needed for FormData; browser sets it.
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    registrationMessage.textContent = 'Driver profile created successfully!';
                    registrationMessage.className = 'message success';
                    driverRegistrationForm.reset(); // Clear the form
                } else {
                    registrationMessage.textContent = data.message || 'Driver registration failed.';
                    registrationMessage.className = 'message error';
                }
            })
            .catch(error => {
                console.error('Error during driver registration:', error);
                registrationMessage.textContent = 'An error occurred during registration. Please try again.';
                registrationMessage.className = 'message error';
            });
            */
        });
    }


    // --- Employer Dashboard (employer_dashboard.html - Conceptual) ---
    // This page is not fully created in HTML yet, but this JS would handle its tabs.
    const employerDashboardTabs = document.querySelectorAll('.employer-dashboard-nav a');
    const dashboardContentSections = document.querySelectorAll('.dashboard-content-section');

    employerDashboardTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = tab.getAttribute('href').substring(1); // Get #id

            // Remove active class from all tabs and add to clicked tab
            employerDashboardTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Hide all content sections and show the target one
            dashboardContentSections.forEach(section => {
                if (section.id === targetId) {
                    section.style.display = 'block';
                    if (targetId === 'show-drivers') {
                        // Call a function to load/display drivers when this tab is active
                        loadDrivers();
                    } else if (targetId === 'pricing') {
                        // Call a function to load pricing if dynamic
                        displayPricing();
                    } else if (targetId === 'support') {
                        // Call a function to load support info if dynamic
                        displaySupportInfo();
                    }
                } else {
                    section.style.display = 'none';
                }
            });
        });
    });

    // Function to simulate loading drivers (for 'Show Drivers' tab)
    function loadDrivers() {
        const driverListContainer = document.getElementById('driverListContainer');
        if (!driverListContainer) return;

        // Simulate fetching verified drivers from backend
        // In a real app, fetch from /api/drivers?status=verified
        const dummyDrivers = [
            {
                name: "Rohan Sharma",
                gender: "Male",
                age: 32,
                experience: 8,
                rating: 4.5,
                contact: "0000000789",
                profilePic: "https://via.placeholder.com/100?text=Driver1"
            },
            {
                name: "Priya Singh",
                gender: "Female",
                age: 28,
                experience: 5,
                rating: 4.2,
                contact: "0000000456",
                profilePic: "https://via.placeholder.com/100?text=Driver2"
            },
            {
                name: "Amit Kumar",
                gender: "Male",
                age: 45,
                experience: 15,
                rating: 4.8,
                contact: "0000000123",
                profilePic: "https://via.placeholder.com/100?text=Driver3"
            }
        ];

        if (dummyDrivers.length === 0) {
            driverListContainer.innerHTML = '<p class="no-drivers-message">No drivers available at the moment. Please check back later!</p>';
        } else {
            driverListContainer.innerHTML = ''; // Clear previous content
            dummyDrivers.forEach(driver => {
                const driverCard = document.createElement('div');
                driverCard.className = 'driver-card';
                driverCard.innerHTML = `
                    <img src="${driver.profilePic}" alt="${driver.name}'s Profile">
                    <h3>${driver.name}</h3>
                    <p>Gender: ${driver.gender}</p>
                    <p>Age: ${driver.age}</p>
                    <p>Experience: ${driver.experience} Years</p>
                    <p class="overall-rating">Rating: ${driver.rating} ⭐</p>
                    <p>Contact: ${driver.contact}</p>
                    <button class="button primary-button book-now-btn" data-driver-id="${driver.name}">Book Now</button>
                `;
                driverListContainer.appendChild(driverCard);
            });

            // Add event listeners for "Book Now" buttons (simulated booking)
            document.querySelectorAll('.book-now-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    const driverName = e.target.dataset.driverId;
                    alert(`Booking ${driverName}! (This would trigger a booking confirmation flow and email.)`);
                    // In a real app, this would initiate a booking process,
                    // send data to backend, and then backend sends email.
                    // For demo, just redirect to confirmation page after alert
                    window.location.href = 'confirmation.html';
                });
            });
        }
    }

    // Function to display pricing (for 'Pricing' tab)
    function displayPricing() {
        const pricingContent = document.getElementById('pricingContent');
        if (!pricingContent) return;

        pricingContent.innerHTML = `
            <div class="pricing-tables">
                <div class="pricing-table">
                    <h3>Per Day Pricing</h3>
                    <ul>
                        <li>Car (Small) <span class="price">₹1000</span></li>
                        <li>Car XL <span class="price">₹1200</span></li>
                        <li>Tractor <span class="price">₹700</span></li>
                        <li>Lorry <span class="price">₹1800</span></li>
                        <li>Bike <span class="price">₹600</span></li>
                        <li>Crane <span class="price">₹1500</span></li>
                        <li>Backhoe Loader <span class="price">₹2200</span></li>
                        <li>Dozers <span class="price">₹2000</span></li>
                    </ul>
                    <p class="pricing-note">Note: additional bonus can be given by the user if interested.</p>
                </div>
                <div class="pricing-table">
                    <h3>Per Hour Pricing</h3>
                    <ul>
                        <li>Car (Small) <span class="price">₹189</span></li>
                        <li>Car XL <span class="price">₹229</span></li>
                        <li>Tractor <span class="price">₹129</span></li>
                        <li>Lorry <span class="price">₹250</span></li>
                        <li>Bike <span class="price">₹89</span></li>
                        <li>Crane <span class="price">₹210</span></li>
                        <li>Backhoe Loader <span class="price">₹300</span></li>
                        <li>Dozers <span class="price">₹280</span></li>
                    </ul>
                    <p class="pricing-note">Note: additional bonus can be given by the user if interested.</p>
                </div>
            </div>
        `;
    }

    // Function to display support info (for 'Support / Help' tab)
    function displaySupportInfo() {
        const supportContent = document.getElementById('supportContent');
        if (!supportContent) return;

        supportContent.innerHTML = `
            <p>Call us at <a href="tel:+919121658449">+91 9121658449</a></p>
            <p>Or</p>
            <p>Please drop a mail at <a href="mailto:driverhunt01@gmail.com">driverhunt01@gmail.com</a></p>
        `;
    }

    // Initial load for employer dashboard (if on that page)
    if (document.getElementById('employerDashboard')) {
        // Automatically click the 'Home' tab or first tab on load
        const initialTab = document.querySelector('.employer-dashboard-nav a.active') || document.querySelector('.employer-dashboard-nav a');
        if (initialTab) {
            initialTab.click();
        }
    }
});