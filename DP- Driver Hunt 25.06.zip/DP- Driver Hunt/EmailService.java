package com.driverhunt.services;

import com.driverhunt.models.Driver;
import com.driverhunt.models.User;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailService {

    private static final String SENDER_EMAIL = "driverhunt01@gmail.com";
    private static final String SENDER_PASSWORD = "Driverhunt@12"; // Use an App Password for Gmail

    public void sendBookingConfirmationEmail(User user, Driver driver) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
            message.setSubject("Your Driver Hunt Booking Confirmation!");

            String emailContent = "Dear " + user.getFullName() + ",\n\n" +
                                  "Your booking was successful!\n\n" +
                                  "Please find the details of your driver:\n" +
                                  "Driver's Name: " + driver.getName() + "\n" +
                                  "Gender: " + driver.getGender() + "\n" +
                                  "Age: " + driver.getAge() + "\n" +
                                  "Experience (Exp): " + driver.getExperience() + " years\n" +
                                  "Overall Rating: " + driver.getOverallRating() + " ⭐\n" +
                                  "Contact Number: " + driver.getPhoneNumber() + "\n\n" +
                                  "Thank you for using Driver Hunt!";

            message.setText(emailContent);

            Transport.send(message);
            System.out.println("Booking confirmation email sent to: " + user.getEmail());

        } catch (MessagingException e) {
            System.err.println("Failed to send email: " + e.getMessage());
            e.printStackTrace();
        }
    }
}