package com.driverhunt.models;

import java.time.LocalDateTime;

public class Booking {
    private int id;
    private int userId;
    private int driverId;
    private LocalDateTime bookingTime;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String vehicleType;
    private String status; // e.g., "Pending", "Confirmed", "Completed", "Cancelled"
    private double estimatedCost;

    // Constructors
    public Booking() {}

    public Booking(int id, int userId, int driverId, LocalDateTime bookingTime, LocalDateTime startTime, LocalDateTime endTime,
                   String vehicleType, String status, double estimatedCost) {
        this.id = id;
        this.userId = userId;
        this.driverId = driverId;
        this.bookingTime = bookingTime;
        this.startTime = startTime;
        this.endTime = endTime;
        this.vehicleType = vehicleType;
        this.status = status;
        this.estimatedCost = estimatedCost;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getDriverId() { return driverId; }
    public void setDriverId(int driverId) { this.driverId = driverId; }

    public LocalDateTime getBookingTime() { return bookingTime; }
    public void setBookingTime(LocalDateTime bookingTime) { this.bookingTime = bookingTime; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getEstimatedCost() { return estimatedCost; }
    public void setEstimatedCost(double estimatedCost) { this.estimatedCost = estimatedCost; }
}