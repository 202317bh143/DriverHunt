package com.driverhunt.controller;

import com.driverhunt.models.Booking;
import com.driverhunt.models.Driver;
import com.driverhunt.models.User;
import com.driverhunt.services.BookingService;
import com.driverhunt.services.DriverService;
import com.driverhunt.services.UserService;
import io.javalin.http.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookingController {
    private BookingService bookingService = new BookingService();
    private DriverService driverService = new DriverService();
    private UserService userService = new UserService(); // Needed to fetch user details for email
    private Gson gson = new Gson();

    public void bookDriver(Context ctx) {
        // Assuming booking request contains userId, driverId, startTime, endTime, vehicleType
        Map<String, Object> bookingRequest = gson.fromJson(ctx.body(), new TypeToken<Map<String, Object>>(){}.getType());

        // Basic validation and type conversion
        int userId = ((Double) bookingRequest.get("userId")).intValue(); // Assuming userId comes as double from JS
        int driverId = ((Double) bookingRequest.get("driverId")).intValue();
        LocalDateTime startTime = LocalDateTime.parse((String) bookingRequest.get("startTime"));
        LocalDateTime endTime = LocalDateTime.parse((String) bookingRequest.get("endTime"));
        String vehicleType = (String) bookingRequest.get("vehicleType");

        // Fetch driver and user details to populate the Booking object and for email
        Driver driver = driverService.getDriverDetails(driverId);
        User user = userService.authenticateUser(String.valueOf(userId), null); // Authenticate by ID, password not needed here

        if (driver == null || user == null) {
            ctx.status(404).json(createResponse("Driver or User not found.", false));
            return;
        }

        Booking booking = new Booking();
        booking.setUserId(userId);
        booking.setDriverId(driverId);
        booking.setBookingTime(LocalDateTime.now());
        booking.setStartTime(startTime);
        booking.setEndTime(endTime);
        booking.setVehicleType(vehicleType);
        booking.setStatus("Pending"); // Initial status

        // Calculate estimated cost (simplified)
        // This should ideally be a more robust calculation based on pricing rules and duration
        double estimatedCost = calculateEstimatedCost(vehicleType, startTime, endTime);
        booking.setEstimatedCost(estimatedCost);


        if (bookingService.createBooking(booking, user, driver)) {
            ctx.status(201).json(createResponse("Booking successful! Confirmation email sent.", true, booking));
        } else {
            ctx.status(500).json(createResponse("Booking failed.", false));
        }
    }

    public void getUserBookings(Context ctx) {
        int userId = ctx.pathParam("userId", Integer.class).get(); // Get userId from path param
        List<Booking> bookings = bookingService.getUserBookings(userId);
        ctx.json(createResponse("User bookings retrieved.", true, bookings));
    }

    private double calculateEstimatedCost(String vehicleType, LocalDateTime startTime, LocalDateTime endTime) {
        // Simple calculation: 200 per hour for all types
        long hours = java.time.Duration.between(startTime, endTime).toHours();
        if (hours == 0) hours = 1; // Minimum 1 hour charge
        return hours * 200; // Placeholder value
        // In a real app, use the pricing logic from the prompt (per day/per hour)
        // You'd need to pass the pricing structure from a config/service.
    }

    private Map<String, Object> createResponse(String message, boolean success) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("success", success);
        return response;
    }

    private Map<String, Object> createResponse(String message, boolean success, Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("success", success);
        response.put("data", data);
        return response;
    }
}