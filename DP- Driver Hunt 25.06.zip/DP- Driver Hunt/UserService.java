package com.driverhunt.services;

import com.driverhunt.dao.UserDao;
import com.driverhunt.models.User;
import org.mindrot.jbcrypt.BCrypt; // For password hashing

public class UserService {
    private UserDao userDao = new UserDao();

    public boolean registerUser(User user) {
        // Hash the password before saving
        String hashedPassword = BCrypt.hashpw(user.getPasswordHash(), BCrypt.gensalt());
        user.setPasswordHash(hashedPassword);
        return userDao.createUser(user);
    }

    public User authenticateUser(String identifier, String password) {
        User user = userDao.getUserByEmailOrPhone(identifier);
        if (user != null && BCrypt.checkpw(password, user.getPasswordHash())) {
            return user;
        }
        return null;
    }
}