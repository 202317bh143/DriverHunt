package com.driverhunt.models;

import java.util.List;

public class Driver {
    private int id;
    private String name;
    private int age;
    private String gender;
    private String dlNumber;
    private List<String> vehiclesCanDrive;
    private int experience; // in years
    private String phoneNumber;
    private String address;
    private String workingTimings;
    private String profilePictureUrl;
    private String idProofUrl;
    private String drivingLicenseUrl;
    private double overallRating; // System-assigned
    private boolean isVerified; // Set by admin after checking uploaded documents

    // Constructors
    public Driver() {}

    public Driver(int id, String name, int age, String gender, String dlNumber, List<String> vehiclesCanDrive,
                  int experience, String phoneNumber, String address, String workingTimings,
                  String profilePictureUrl, String idProofUrl, String drivingLicenseUrl, double overallRating, boolean isVerified) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.dlNumber = dlNumber;
        this.vehiclesCanDrive = vehiclesCanDrive;
        this.experience = experience;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.workingTimings = workingTimings;
        this.profilePictureUrl = profilePictureUrl;
        this.idProofUrl = idProofUrl;
        this.drivingLicenseUrl = drivingLicenseUrl;
        this.overallRating = overallRating;
        this.isVerified = isVerified;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getDlNumber() { return dlNumber; }
    public void setDlNumber(String dlNumber) { this.dlNumber = dlNumber; }

    public List<String> getVehiclesCanDrive() { return vehiclesCanDrive; }
    public void setVehiclesCanDrive(List<String> vehiclesCanDrive) { this.vehiclesCanDrive = vehiclesCanDrive; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getWorkingTimings() { return workingTimings; }
    public void setWorkingTimings(String workingTimings) { this.workingTimings = workingTimings; }

    public String getProfilePictureUrl() { return profilePictureUrl; }
    public void setProfilePictureUrl(String profilePictureUrl) { this.profilePictureUrl = profilePictureUrl; }

    public String getIdProofUrl() { return idProofUrl; }
    public void setIdProofUrl(String idProofUrl) { this.idProofUrl = idProofUrl; }

    public String getDrivingLicenseUrl() { return drivingLicenseUrl; }
    public void setDrivingLicenseUrl(String drivingLicenseUrl) { this.drivingLicenseUrl = drivingLicenseUrl; }

    public double getOverallRating() { return overallRating; }
    public void setOverallRating(double overallRating) { this.overallRating = overallRating; }

    public boolean isVerified() { return isVerified; }
    public void setVerified(boolean verified) { isVerified = verified; }
}