package com.driverhunt.services;

import com.driverhunt.dao.DriverDao;
import com.driverhunt.models.Driver;
import java.util.List;

public class DriverService {
    private DriverDao driverDao = new DriverDao();

    public boolean registerDriver(Driver driver) {
        // Initial values for a new driver
        driver.setOverallRating(0.0); // No ratings yet
        driver.setVerified(false); // Awaiting admin verification
        return driverDao.createDriver(driver);
    }

    public List<Driver> getAvailableDrivers() {
        // In a real application, you might add logic for availability (e.g., based on working hours, existing bookings)
        return driverDao.getAllVerifiedDrivers();
    }

    public Driver getDriverDetails(int driverId) {
        return driverDao.getDriverById(driverId);
    }

    // Method for admin to verify driver
    public boolean verifyDriver(int driverId, boolean verifiedStatus) {
        // This would involve updating the 'is_verified' field in the database
        // For simplicity, not implemented in DAO yet, but would be a driverDao.updateDriver(driver); call
        Driver driver = driverDao.getDriverById(driverId);
        if (driver != null) {
            driver.setVerified(verifiedStatus);
            // driverDao.updateDriver(driver); // You would need to add an update method in DriverDao
            return true; // Simulate success
        }
        return false;
    }
}