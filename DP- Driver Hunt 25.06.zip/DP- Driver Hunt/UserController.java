package com.driverhunt.controller;

import com.driverhunt.models.User;
import com.driverhunt.services.UserService;
import io.javalin.http.Context;
import com.google.gson.Gson; // Or use Jackson if preferred

import java.util.HashMap;
import java.util.Map;

public class UserController {
    private UserService userService = new UserService();
    private Gson gson = new Gson();

    public void registerUser(Context ctx) {
        User user = ctx.bodyAsClass(User.class); // Javalin automatically maps JSON to object
        // Perform server-side validation here
        if (user.getFullName() == null || user.getFullName().isEmpty() ||
            user.getPhone() == null || !user.getPhone().matches("[0-9]{10}") || // Basic phone validation
            user.getEmail() == null || !user.getEmail().matches("\\S+@\\S+\\.\\S+") || // Basic email validation
            user.getPasswordHash() == null || user.getPasswordHash().length() < 6) {
            ctx.status(400).json(createResponse("Invalid user data.", false));
            return;
        }

        // The password sent by client is in passwordHash field for convenience, but it's plain text here.
        // UserService will hash it.
        if (userService.registerUser(user)) {
            ctx.status(201).json(createResponse("Account created successfully!", true));
        } else {
            ctx.status(409).json(createResponse("Registration failed. Email or phone might already be in use.", false));
        }
    }

    public void loginUser(Context ctx) {
        // Expecting { "identifier": "email_or_phone", "password": "plain_password" }
        Map<String, String> loginRequest = gson.fromJson(ctx.body(), new TypeToken<Map<String, String>>(){}.getType());
        String identifier = loginRequest.get("identifier");
        String password = loginRequest.get("password");

        if (identifier == null || identifier.isEmpty() || password == null || password.isEmpty()) {
            ctx.status(400).json(createResponse("Identifier and password are required.", false));
            return;
        }

        User user = userService.authenticateUser(identifier, password);
        if (user != null) {
            // For a real application, create and return a JWT token here
            ctx.json(createResponse("Login successful!", true));
            ctx.sessionAttribute("userId", user.getId()); // Simple session management for demo
        } else {
            ctx.status(401).json(createResponse("Invalid email/phone or password.", false));
        }
    }

    private Map<String, Object> createResponse(String message, boolean success) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("success", success);
        return response;
    }
}