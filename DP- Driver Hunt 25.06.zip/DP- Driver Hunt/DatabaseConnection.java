package com.driverhunt.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String JDBC_URL = "jdbc:h2:./data/driverhunt_db"; // H2 database file
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
    }

    public static void init() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            // Create users table
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY," +
                         "full_name VARCHAR(255) NOT NULL," +
                         "phone VARCHAR(15) UNIQUE NOT NULL," +
                         "email VARCHAR(255) UNIQUE NOT NULL," +
                         "address VARCHAR(255)," +
                         "password_hash VARCHAR(255) NOT NULL" +
                         ");");

            // Create drivers table
            stmt.execute("CREATE TABLE IF NOT EXISTS drivers (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY," +
                         "name VARCHAR(255) NOT NULL," +
                         "age INT NOT NULL," +
                         "gender VARCHAR(50) NOT NULL," +
                         "dl_number VARCHAR(100) UNIQUE NOT NULL," +
                         "vehicles_can_drive VARCHAR(500)," + // Stored as JSON string
                         "experience INT NOT NULL," +
                         "phone_number VARCHAR(15) UNIQUE NOT NULL," +
                         "address VARCHAR(255)," +
                         "working_timings VARCHAR(255)," +
                         "profile_picture_url VARCHAR(255)," +
                         "id_proof_url VARCHAR(255)," +
                         "driving_license_url VARCHAR(255)," +
                         "overall_rating DOUBLE DEFAULT 0.0," +
                         "is_verified BOOLEAN DEFAULT FALSE" +
                         ");");

            // Create bookings table
            stmt.execute("CREATE TABLE IF NOT EXISTS bookings (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY," +
                         "user_id INT NOT NULL," +
                         "driver_id INT NOT NULL," +
                         "booking_time TIMESTAMP NOT NULL," +
                         "start_time TIMESTAMP NOT NULL," +
                         "end_time TIMESTAMP NOT NULL," +
                         "vehicle_type VARCHAR(100) NOT NULL," +
                         "status VARCHAR(50) NOT NULL," + // e.g., Pending, Confirmed, Completed
                         "estimated_cost DOUBLE," +
                         "FOREIGN KEY (user_id) REFERENCES users(id)," +
                         "FOREIGN KEY (driver_id) REFERENCES drivers(id)" +
                         ");");

            System.out.println("Database initialized successfully (tables created/verified).");

        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}