package com.driverhunt;

import com.driverhunt.controller.UserController;
import com.driverhunt.controller.DriverController;
import com.driverhunt.controller.BookingController;
import com.driverhunt.util.DatabaseConnection;
import io.javalin.Javalin; // Example for a lightweight web framework for Java
import io.javalin.http.UploadedFile;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

public class DriverHuntApp {
    public static void main(String[] args) {
        // Initialize database connection
        DatabaseConnection.init();

        Javalin app = Javalin.create(config -> {
            config.staticFiles.add("/public"); // Serve static HTML, CSS, JS files
            // You might need to adjust this path based on where your static files are relative to your JAR
        }).start(7000); // Start server on port 7000

        // Initialize controllers (which will use services and DAOs)
        UserController userController = new UserController();
        DriverController driverController = new DriverController();
        BookingController bookingController = new BookingController();

        // User Endpoints
        app.post("/api/signup", userController::registerUser);
        app.post("/api/login", userController::loginUser);

        // Driver Endpoints
        app.post("/api/registerDriver", driverController::registerDriver);
        app.get("/api/drivers", driverController::getVerifiedDrivers);
        app.get("/api/drivers/{id}", driverController::getDriverDetails); // To fetch specific driver details

        // Booking Endpoints
        app.post("/api/bookDriver", bookingController::bookDriver);
        app.get("/api/bookings/{userId}", bookingController::getUserBookings);

        // Example for file upload handling (within a controller or service)
        // This is a simplified example; proper error handling and security checks are needed
        app.post("/api/upload", ctx -> {
            UploadedFile file = ctx.uploadedFile("file"); // "file" is the name of the input field
            if (file != null) {
                try (InputStream inputStream = file.getContent()) {
                    String uploadDir = "uploads"; // Directory to save uploaded files
                    Files.createDirectories(Paths.get(uploadDir));
                    String fileName = UUID.randomUUID().toString() + "_" + file.getFilename();
                    Path filePath = Paths.get(uploadDir, fileName);
                    Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
                    ctx.json(new Response("File uploaded successfully: " + fileName, true));
                } catch (Exception e) {
                    ctx.status(500).json(new Response("File upload failed: " + e.getMessage(), false));
                }
            } else {
                ctx.status(400).json(new Response("No file uploaded.", false));
            }
        });

        System.out.println("Driver Hunt Backend Started on http://localhost:7000");
    }

    // Simple Response class for JSON feedback
    static class Response {
        public String message;
        public boolean success;

        public Response(String message, boolean success) {
            this.message = message;
            this.success = success;
        }
    }
}