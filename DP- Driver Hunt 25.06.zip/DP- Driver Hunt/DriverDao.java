package com.driverhunt.dao;

import com.driverhunt.models.Driver;
import com.driverhunt.util.DatabaseConnection;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DriverDao {

    private Gson gson = new Gson(); // For converting List<String> to/from JSON string

    public Driver getDriverById(int id) {
        String sql = "SELECT * FROM drivers WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToDriver(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Driver> getAllVerifiedDrivers() {
        List<Driver> drivers = new ArrayList<>();
        String sql = "SELECT * FROM drivers WHERE is_verified = TRUE";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                drivers.add(mapResultSetToDriver(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return drivers;
    }

    public boolean createDriver(Driver driver) {
        String sql = "INSERT INTO drivers (name, age, gender, dl_number, vehicles_can_drive, experience, phone_number, address, working_timings, profile_picture_url, id_proof_url, driving_license_url, overall_rating, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, driver.getName());
            pstmt.setInt(2, driver.getAge());
            pstmt.setString(3, driver.getGender());
            pstmt.setString(4, driver.getDlNumber());
            pstmt.setString(5, gson.toJson(driver.getVehiclesCanDrive())); // Convert list to JSON string
            pstmt.setInt(6, driver.getExperience());
            pstmt.setString(7, driver.getPhoneNumber());
            pstmt.setString(8, driver.getAddress());
            pstmt.setString(9, driver.getWorkingTimings());
            pstmt.setString(10, driver.getProfilePictureUrl());
            pstmt.setString(11, driver.getIdProofUrl());
            pstmt.setString(12, driver.getDrivingLicenseUrl());
            pstmt.setDouble(13, driver.getOverallRating());
            pstmt.setBoolean(14, driver.isVerified());
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        driver.setId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Driver mapResultSetToDriver(ResultSet rs) throws SQLException {
        Type listOfStrings = new TypeToken<List<String>>() {}.getType();
        List<String> vehicles = gson.fromJson(rs.getString("vehicles_can_drive"), listOfStrings);

        return new Driver(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getInt("age"),
            rs.getString("gender"),
            rs.getString("dl_number"),
            vehicles,
            rs.getInt("experience"),
            rs.getString("phone_number"),
            rs.getString("address"),
            rs.getString("working_timings"),
            rs.getString("profile_picture_url"),
            rs.getString("id_proof_url"),
            rs.getString("driving_license_url"),
            rs.getDouble("overall_rating"),
            rs.getBoolean("is_verified")
        );
    }
}